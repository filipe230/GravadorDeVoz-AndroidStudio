package com.example.gravadordevoz;

import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;


public class MainActivity extends AppCompatActivity {
    private ImageButton btnGravar, btnPausar, btnPlay, btnParar;
    private TextView txtAcao;

    // creating a variable for medi recorder object class.
    private MediaRecorder recorder = null;

    // creating a variable for mediaplayer class
    private MediaPlayer mPlayer;

    // string variable is created for storing a file name
    private static String mFileName = null;

    public static final int REQUEST_AUDIO_PERMISSION_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtAcao = findViewById(R.id.txtAcao);
        btnGravar = findViewById(R.id.imgBtnGravar);
        btnPausar = findViewById(R.id.imgBtnPausar);
        btnPlay = findViewById(R.id.imgBtnPlay);
        btnParar = findViewById(R.id.imgBtnParar);

        btnParar.setBackgroundColor(getResources().getColor(R.color.gray));
        btnPlay.setBackgroundColor(getResources().getColor(R.color.gray));
        btnPausar.setBackgroundColor(getResources().getColor(R.color.gray));

        btnGravar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gravar();
            }
        });

        btnParar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pararGravar();
            }
        });

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playAudio();
            }
        });

        btnPausar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pararAudio();
            }
        });

        }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_AUDIO_PERMISSION_CODE:
                if (grantResults.length > 0) {
                    boolean permissionToRecord = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean permissionToStore = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (permissionToRecord && permissionToStore) {
                        Toast.makeText(getApplicationContext(), "Permission Granted", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_LONG).show();
                    }
                }
                break;
        }
    }

    public boolean CheckPermissions() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), RECORD_AUDIO);
        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }

    private void RequestPermissions() {
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{RECORD_AUDIO, WRITE_EXTERNAL_STORAGE}, REQUEST_AUDIO_PERMISSION_CODE);
    }

    private void gravar() {
        if (CheckPermissions()) {
            btnParar.setBackgroundColor(getResources().getColor(R.color.green));
            btnGravar.setBackgroundColor(getResources().getColor(R.color.gray));
            btnPlay.setBackgroundColor(getResources().getColor(R.color.gray));
            btnPausar.setBackgroundColor(getResources().getColor(R.color.gray));

            Toast.makeText(getApplicationContext(), "Depois do background", Toast.LENGTH_LONG).show();

            // below method is used to initialize
            // the media recorder clss
            recorder = new MediaRecorder();
            Toast.makeText(getApplicationContext(), "Depois do MediaRecorder", Toast.LENGTH_LONG).show();


            // below method is used to set the audio
            // source which we are using a mic.
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            Toast.makeText(getApplicationContext(), "Depois do setAudioSource", Toast.LENGTH_LONG).show();

            // below method is used to set
            // the output format of the audio.
            recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            Toast.makeText(getApplicationContext(), "Depois do setOutputFormat", Toast.LENGTH_LONG).show();

            // below method is used to set the
            // audio encoder for our recorded audio.
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            Toast.makeText(getApplicationContext(), "Depois do setAudioEncoder", Toast.LENGTH_LONG).show();

            // below method is used to set the
            // output file location for our recorded audio
            recorder.setOutputFile(mFileName);
            Toast.makeText(getApplicationContext(), "Depois do mFileName", Toast.LENGTH_LONG).show();

            try {
                // below method will prepare
                // our audio recorder class
                Toast.makeText(getApplicationContext(), "Antes do mRecorder.prepare()", Toast.LENGTH_LONG).show();
                recorder.prepare();
                Toast.makeText(getApplicationContext(), "Depois do mRecorder.prepare()", Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                Log.e("TAG", "prepare() failed");
                Toast.makeText(getApplicationContext(), "Dentro do catch", Toast.LENGTH_LONG).show();
            }
            // start method will start
            // the audio recording.
            Toast.makeText(getApplicationContext(), "Antes do start", Toast.LENGTH_LONG).show();

            recorder.start();
            Toast.makeText(getApplicationContext(), "Depois do start", Toast.LENGTH_LONG).show();

            txtAcao.setText("Recording Started");
        } else {
            // if audio recording permissions are
            // not granted by user below method will
            // ask for runtime permission for mic and storage.
            RequestPermissions();
        }
    }

    public void pararGravar() {
        btnParar.setBackgroundColor(getResources().getColor(R.color.gray));
        btnGravar.setBackgroundColor(getResources().getColor(R.color.green));
        btnPlay.setBackgroundColor(getResources().getColor(R.color.green));
        btnPausar.setBackgroundColor(getResources().getColor(R.color.gray));

        recorder.stop();

        // below method will release
        // the media recorder class.
        recorder.release();
        recorder = null;
        txtAcao.setText("Recording Stopped");
    }

    public void playAudio() {
        btnParar.setBackgroundColor(getResources().getColor(R.color.gray));
        btnGravar.setBackgroundColor(getResources().getColor(R.color.green));
        btnPlay.setBackgroundColor(getResources().getColor(R.color.gray));
        btnPausar.setBackgroundColor(getResources().getColor(R.color.green));

        mPlayer = new MediaPlayer();
        try {
            // below method is used to set the
            // data source which will be our file name
            mPlayer.setDataSource(mFileName);

            // below method will prepare our media player
            mPlayer.prepare();

            // below method will start our media player.
            mPlayer.start();
            txtAcao.setText("Recording Started Playing");
        } catch (IOException e) {
            Log.e("TAG", "prepare() failed");
        }
    }

    public void pararAudio() {

        mPlayer.release();
        mPlayer = null;

        btnParar.setBackgroundColor(getResources().getColor(R.color.gray));
        btnGravar.setBackgroundColor(getResources().getColor(R.color.green));
        btnPlay.setBackgroundColor(getResources().getColor(R.color.green));
        btnPausar.setBackgroundColor(getResources().getColor(R.color.gray));

        txtAcao.setText("Recording Play Stopped");
    }

    }